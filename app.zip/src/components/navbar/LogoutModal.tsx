'use client';
import React from 'react';
import logout from '@/public/images/logout.png';
import Image from 'next/image';
import apiServiceCall from '@/lib/apiServiceCall';
import { useLocale, useTranslations } from 'next-intl';
import { toast } from 'react-toastify';

interface LogoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  token: string;
}

const LogoutModal: React.FC<LogoutModalProps> = ({ isOpen, onClose, token }) => {
  const locale = useLocale();
  const t = useTranslations('Logout');

  const handleLogout = () => {
    const performLocalLogout = () => {
      if (typeof window !== 'undefined') {
        localStorage.removeItem("alomran_current_user");
      }
      fetch("/api/auth/logout", { method: "GET" })
        .then(() => {
          window.location.reload();
        });
    };

    apiServiceCall({
      url: 'client/auth/logout',
      method: 'POST',
      body: {
        device_token: null,
      },
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
      .then((res) => {
        if (res?.message) {
          toast.success(res.message);
        } else {
          toast.success(t('successMessage'));
        }
        performLocalLogout();
      })
      .catch((error) => {
        console.warn("API logout failed, performing local logout fallback...", error);
        performLocalLogout();
      });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center !z-[9999999] p-4">
      <div className="bg-white relative rounded-[15px] p-6 w-full max-w-md flex flex-col items-center">
        <button
          onClick={onClose}
          className="absolute top-3 right-3 text-gray-500 hover:text-black text-2xl"
          aria-label="Close Modal"
        >
          &times;
        </button>
        <h2 className="text-[22px] font-extrabold mb-4 text-primary">{t('title')}</h2>
        <p className="mb-6 text-[#989898] font-medium text-base">
          {t('description')}
        </p>
        <button
          onClick={handleLogout}
          className="px-4 py-2 bg-primary mt-5 text-white rounded-md flex items-center gap-2 justify-center w-full h-[62px]"
        >
          <Image src={logout} alt="logout" />
          {t('confirm')}
        </button>
      </div>
    </div>
  );
};

export default LogoutModal;
